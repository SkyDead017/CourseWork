<?php
header('Content-Type: text/html; charset=utf-8');
mb_internal_encoding('UTF-8');

session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    $dbname = 'AutomotiveManufacturingCompany';

    // Валидация ввода
    if (empty($login) || empty($password)) {
        $error = 'Логин и пароль обязательны для заполнения';
    } else {
        try {
            // Подавляем стандартные предупреждения MySQL
            $mysqli = @new mysqli('MySQL-8.0', $login, $password, $dbname, 3306);
            
            if ($mysqli->connect_errno) {
                // Для всех ошибок подключения показываем одинаковое сообщение
                $error = 'Неверный логин или пароль';
                error_log('MySQL Connection Error #' . $mysqli->connect_errno . ': ' . $mysqli->connect_error);
            } else {
                $mysqli->set_charset('utf8mb4');
                
                $_SESSION['db_connection'] = true;
                $_SESSION['user_role'] = $login;
                $_SESSION['db_login'] = $login;
                $_SESSION['db_password'] = $password;

                switch ($login) {
                    case 'developer':
                        header('Location: developer_panel.php');
                        break;
                    case 'chief':
                        header('Location: chief_panel.php');
                        break;
                    case 'employee':
                        header('Location: employee_panel.php');
                        break;
                    default:
                        header('Location: dashboard.php');
                }
                exit();
            }
        } catch (Exception $e) {
            $error = 'Неверный логин или пароль';
            error_log('MySQL Exception: ' . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Автомобилестроительное предприятие</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background: #f4f4f9; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
        }
        .login-form { 
            background: white; 
            padding: 20px; 
            border-radius: 8px; 
            box-shadow: 0 0 10px rgba(0,0,0,0.1); 
            width: 300px; 
        }
        .login-form h2 { 
            text-align: center; 
            margin-bottom: 20px; 
        }
        .form-group { 
            margin-bottom: 15px; 
        }
        .form-group label { 
            display: block; 
            margin-bottom: 5px; 
        }
        .form-group input { 
            width: 100%; 
            padding: 8px; 
            box-sizing: border-box; 
            border: 1px solid #ddd; 
            border-radius: 4px; 
        }
        .error { 
            color: red; 
            text-align: center; 
            margin-bottom: 15px;
            padding: 10px;
            background: #ffeeee;
            border: 1px solid #ffcccc;
            border-radius: 4px;
        }
        button { 
            width: 100%; 
            padding: 10px; 
            background: #4CAF50; 
            color: white; 
            border: none; 
            border-radius: 4px; 
            cursor: pointer; 
        }
        button:hover { 
            background: #45a049; 
        }
    </style>
</head>
<body>
    <div class="login-form">
        <h2>Вход в систему</h2>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label for="login">Логин:</label>
                <input type="text" id="login" name="login" required value="<?= isset($_POST['login']) ? htmlspecialchars($_POST['login']) : '' ?>">
            </div>
            <div class="form-group">
                <label for="password">Пароль:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Войти</button>
        </form>
    </div>
</body>
</html>