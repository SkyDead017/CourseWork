/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    IDENTIFIER = 258,              /* IDENTIFIER  */
    PLAYER_REF = 259,              /* PLAYER_REF  */
    STRING_LITERAL = 260,          /* STRING_LITERAL  */
    NUMBER_LITERAL = 261,          /* NUMBER_LITERAL  */
    FORMATION = 262,               /* FORMATION  */
    END_FORMATION = 263,           /* END_FORMATION  */
    SEQUENCE = 264,                /* SEQUENCE  */
    END_SEQUENCE = 265,            /* END_SEQUENCE  */
    PLAYERS = 266,                 /* PLAYERS  */
    PLAY = 267,                    /* PLAY  */
    END_PLAY = 268,                /* END_PLAY  */
    DRILL = 269,                   /* DRILL  */
    END_DRILL = 270,               /* END_DRILL  */
    TIMES = 271,                   /* TIMES  */
    AS = 272,                      /* AS  */
    QUARTER = 273,                 /* QUARTER  */
    END_QUARTER = 274,             /* END_QUARTER  */
    EXERCISE = 275,                /* EXERCISE  */
    END_EXERCISE = 276,            /* END_EXERCISE  */
    SETS = 277,                    /* SETS  */
    END_SETS = 278,                /* END_SETS  */
    REPS = 279,                    /* REPS  */
    END_REPS = 280,                /* END_REPS  */
    WHEN = 281,                    /* WHEN  */
    END_WHEN = 282,                /* END_WHEN  */
    THEN = 283,                    /* THEN  */
    OTHERWISE = 284,               /* OTHERWISE  */
    HUDDLE = 285,                  /* HUDDLE  */
    EXECUTE = 286,                 /* EXECUTE  */
    CALL = 287,                    /* CALL  */
    RETURN = 288,                  /* RETURN  */
    RECRUIT = 289,                 /* RECRUIT  */
    BREAK_EXERCISE = 290,          /* BREAK_EXERCISE  */
    SCORE_OP = 291,                /* SCORE_OP  */
    PLUS_OP = 292,                 /* PLUS_OP  */
    MINUS_OP = 293,                /* MINUS_OP  */
    MULTIPLY = 294,                /* MULTIPLY  */
    DIVIDE = 295,                  /* DIVIDE  */
    MODULO = 296,                  /* MODULO  */
    GT_OP = 297,                   /* GT_OP  */
    LT_OP = 298,                   /* LT_OP  */
    ASSIGN_OP = 299,               /* ASSIGN_OP  */
    EQUALS_OP = 300,               /* EQUALS_OP  */
    AND_OP = 301,                  /* AND_OP  */
    COMMA = 302,                   /* COMMA  */
    COLON = 303,                   /* COLON  */
    SEMICOLON = 304,               /* SEMICOLON  */
    LBRACE = 305,                  /* LBRACE  */
    RBRACE = 306,                  /* RBRACE  */
    LPAREN = 307,                  /* LPAREN  */
    RPAREN = 308,                  /* RPAREN  */
    LBRACKET = 309,                /* LBRACKET  */
    RBRACKET = 310,                /* RBRACKET  */
    WITH = 311                     /* WITH  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 79 "parser.y"
 char* string_value; struct ASTNode* node; 

#line 123 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
