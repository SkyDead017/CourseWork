#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Helpers
char* __gp_to_str(int v) { char* b = malloc(32); sprintf(b, "%d", v); return b; }
char* __gp_concat(char* a, char* b) { 
    char* res = malloc(strlen(a) + strlen(b) + 1); 
    strcpy(res, a); strcat(res, b); return res; 
}

void func_show_standings();

// Переменные
int gp_team_scores_arr[100] = {0};
int gp_count = 0;
int gp_i = 0;
int gp_j = 0;
int gp_k = 0;
int gp_next_idx = 0;
int gp_val_current = 0;
int gp_val_next = 0;
int gp_temp = 0;
int gp_total_score = 0;
int gp_average_approx = 0;

int main() {
    { int count = 9; for(int i=0; i<count && i<100; i++) gp_team_scores_arr[i] = 0; }
    gp_count = 0;
    gp_i = 0;
    gp_j = 0;
    gp_k = 0;
    gp_next_idx = 0;
    gp_val_current = 0;
    gp_val_next = 0;
    gp_temp = 0;
    gp_total_score = 0;
    gp_average_approx = 0;

    // Код
    printf("%s\n", "Coach, how many players to sort (max 10)?");
    if(scanf("%d", &gp_count)!=1) { printf("Error: Number expected\n"); exit(1); }
    printf("%s\n", "Enter scores for each player:");
    for(gp_i = 0; gp_i < gp_count; gp_i++) {
    printf("%s\n", "Score for player:");
    if(scanf("%d", &gp_team_scores_arr[gp_i])!=1) { printf("Error: Number expected\n"); exit(1); }
    }
    printf("%s\n", "--- Starting Bubble Sort Drill ---");
    for(gp_i = 0; gp_i < gp_count; gp_i++) {
    for(gp_j = 0; gp_j < gp_count; gp_j++) {
    gp_next_idx = (gp_j + 1);
    if ((gp_next_idx < gp_count)) {
    gp_val_current = gp_team_scores_arr[gp_j];
    gp_val_next = gp_team_scores_arr[gp_next_idx];
    if ((gp_val_current > gp_val_next)) {
    gp_temp = gp_val_current;
    gp_team_scores_arr[gp_j] = gp_val_next;
    gp_team_scores_arr[gp_next_idx] = gp_temp;
    }
    }
    }
    }
    func_show_standings();
    printf("%s\n", "--- Calculating Stats ---");
    for(gp_k = 0; gp_k < gp_count; gp_k++) {
    gp_total_score += gp_team_scores_arr[gp_k];
    }
    printf("%s\n", "Total Team Score:");
    printf("%d\n", gp_total_score);
    gp_average_approx = (gp_total_score / gp_count);
    gp_average_approx = (gp_average_approx * 10);
    printf("%s\n", "Average Score (x10 scaled):");
    printf("%d\n", gp_average_approx);

    return 0;
}

void func_show_standings() {
    printf("%s\n", "--- Final Standings (Sorted) ---");
    for(gp_k = 0; gp_k < gp_count; gp_k++) {
    printf("%d\n", gp_team_scores_arr[gp_k]);
    }
}
